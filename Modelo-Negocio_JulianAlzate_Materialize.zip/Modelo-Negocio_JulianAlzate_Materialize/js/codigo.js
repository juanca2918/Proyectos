$(document).ready(function(){
  M.AutoInit();
    $('.parallax').parallax();
});
